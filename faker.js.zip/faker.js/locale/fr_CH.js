var Faker = require('../lib');
var faker = new Faker({ locale: 'fr_CH', localeFallback: 'en' });
faker.locales['fr_CH'] = require('../lib/locales/fr_CH');
faker.locales['en'] = require('../lib/locales/en');
module['exports'] = faker;
